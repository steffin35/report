# .streamlit/config.toml
[theme]
primaryColor="#530e92"
backgroundColor="#ba79ec"
secondaryBackgroundColor="#a150d0"
textColor="#000000"
font="sans serif"